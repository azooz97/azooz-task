<?php $__env->startSection('content'); ?>



    <div class="card">

        <div class="collapse-content">

            <div class="collapse" id="collapseExample">

                <table class="table table-borderless table-sm mb-0">
                    <tbody>
                    <label>azooz</label>
                    </tbody>
                </table>

            </div>

            <hr class="">

            <a class="btn btn-flat red-text p-1 my-1 mr-0 mml-1 deep-purple-text collapsed" data-toggle="collapse"
               href="#collapseExample" aria-expanded="false" aria-controls="collapseExample"></a>

        </div>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalTry2\resources\views/welcome.blade.php ENDPATH**/ ?>