<?php $__env->startSection('content'); ?>


    <div class="container">
        <form action="/profile" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="row justify-content-center">
                <div class="col-md-6">

                    <div class="cards">

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card"
                                 style="text-align: center; margin: 10px;background-color: rgba(121,121,121,0.15) ">

                                
                                <div class="card-img-top" style="margin: 10px">
                                    <img src="images/default.png" class="img card-img-top" alt="avatar"
                                         style="width: 150px; height: 150px; border-radius: 50%;">
                                </div>

                                <hr>
                                

                                
                                <h2><?php echo e($user->fName); ?> <?php echo e($user->lName); ?></h2>

                                
                                <h4><?php echo e($user->major); ?></h4>

                                <button name="btn" id="btn" class="btn btn-primary " value=<?php echo e($user->id); ?>>More info
                                </button>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalTry2\resources\views/home.blade.php ENDPATH**/ ?>