<?php $__env->startSection('content'); ?>

    <div class="container">
        <form action="/appointments/create" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="row justify-content-center">
                <div class="col-md-6">

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card" style="margin: 10px;background-color: rgba(121,121,121,0.15) ">

                            
                            <div class="card-img-top" style="text-align: center;margin: 10px">
                                <img src="images/default.png" class="img card-img-top" alt="avatar"
                                     style="width: 150px; height: 150px; border-radius: 50%;">
                            </div>

                            <hr>

                            
                            <h2 style="text-align: center"><?php echo e($user->fName); ?> <?php echo e($user->lName); ?></h2>

                            
                            <h4 style="text-align: center"><?php echo e($user->major); ?></h4>

                            <div class="card" style="margin: 20px; border-radius: 5%;
                             text-align: center; height: 80px;justify-content: center">

                                <h5>Country: <?php echo e($user->country); ?> </h5>
                                <h5>Working
                                    hours: <?php echo e(((int)date('h',strtotime($user->sTime))).(date('A',strtotime($user->sTime)))); ?>

                                    -> <?php echo e(((int)date('h',strtotime($user->eTime))).(date('A',strtotime($user->eTime)))); ?> </h5>

                            </div>


                            <button name="btn" id="btn" class="btn btn-primary "
                                    value=<?php echo e($user->id); ?>>Book now
                            </button>


                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </form>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalTry2\resources\views/profile.blade.php ENDPATH**/ ?>