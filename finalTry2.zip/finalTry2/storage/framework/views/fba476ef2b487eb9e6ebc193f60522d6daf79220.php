<?php $__env->startSection('content'); ?>



    <div class="container">
        <form action="/store" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="row justify-content-center">
                <div class="col-md-6">

                    <div class="card "
                         style="text-align: center;margin: 10px; background-color: rgba(121,121,121,0.15)">

                        <div class="card-header">Appointment</div>

                        
                        <div class="div" style="margin: 10px">
                            <label for="date" style="font-size: large; margin-right: 10px">Select date</label>
                            <input type="date" name="date" id="date">

                            
                            <h4 style="margin: 10px">Time zone: <?php echo e(auth()->user()->timezone); ?>

                            </h4>

                        </div>

                        
                        <div class="div" style="margin: 10px">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="duration">Duration</label>
                                </div>

                                <select class="custom-select" id="duration" name="duration">
                                    <option value="0">Choose...</option>
                                    <option value="15">15 min</option>
                                    <option value="30">30 min</option>
                                    <option value="45">45 min</option>
                                    <option value="60">1 hour</option>
                                </select>

                            </div>
                        </div>

                        <div class="div" style="margin: 10px">

                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="duration">Duration</label>
                                </div>


                                <select class="custom-select" id="time" name="time" disabled>

                                    
                                    
                                    
                                    

                                    <h5 hidden>
                                        <?php echo e($i=(int)(date("g",strtotime($users[0]->sTime)))); ?>

                                        <?php echo e($j=(int)(date("g",strtotime($users[0]->eTime)))); ?>

                                        <?php echo e($x=date("A",strtotime($users[0]->sTime))); ?>

                                        <?php echo e($y=date("A",strtotime($users[0]->eTime))); ?>

                                        <?php echo e($am='AM'); ?>

                                        <?php echo e($pm='PM'); ?>

                                    </h5>

                                    <option value=<?php echo e($i.":00 ".$x); ?>><?php echo e($i.":00 ".$x); ?></option>
                                    <?php while($i!=$j || $x!=$y): ?>

                                        
                                        
                                        

                                        <option value=<?php echo e($i.":15 ".$x); ?>><?php echo e($i.":15 ".$x); ?></option>
                                        <option value=<?php echo e($i.":30 ".$x); ?>><?php echo e($i.":30 ".$x); ?></option>
                                        <option value=<?php echo e($i.":45 ".$x); ?>><?php echo e($i.":45 ".$x); ?></option>
                                        <?php if(($i+1)<12): ?>
                                            <option value=<?php echo e(($i+1).":00 ".$x); ?>><?php echo e(($i+1).":00 ".$x); ?></option>
                                        <?php else: ?>
                                            <h5 hidden>
                                                <?php if($x=$am): ?>
                                                    <?php echo e($x=$pm); ?>

                                                <?php else: ?>
                                                    <?php echo e($x=$am); ?>

                                                <?php endif; ?></h5>
                                            <option value=<?php echo e((1).":00 ".$x); ?>><?php echo e((1).":00 ".$x); ?></option>
                                        <?php endif; ?>

                                        <h5 hidden>
                                            <?php echo e($i++); ?>

                                            <?php if($i>12): ?>
                                                <?php echo e($i=1); ?>

                                                <?php if($x=$am): ?>
                                                    <?php echo e($x=$pm); ?>

                                                <?php else: ?>
                                                    <?php echo e($x=$am); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </h5>

                                    <?php endwhile; ?>


                                </select>
                                
                                <script>
                                    document.getElementById('duration').addEventListener('change', function () {
                                        document.getElementById('time').disabled = this.value == 0;
                                    });
                                </script>
                            </div>

                        </div>

                        
                        <button type="submit" class=" btn btn-primary " >Submit</button>


                    </div>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalTry2\resources\views/appointments/create.blade.php ENDPATH**/ ?>