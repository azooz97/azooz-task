<?php $__env->startSection('content'); ?>


    <div class="container">
        <form action="/store" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="row justify-content-center">
                <div class="col-md-6">

                    <div class="card "
                         style="text-align: center;margin: 10px; background-color: rgba(121,121,121,0.15)">

                        <div class="card-header">Appointment</div>

                        
                        <div class="div" style="margin: 10px">
                            <label for="date" style="font-size: large; margin-right: 10px">Select date</label>
                            <input type="date" name="date" id="date" value=null min="<?php echo e(date("Y-m-d")); ?>">

                            
                            <h4 style="margin: 10px">Time zone: <?php echo e(auth()->user()->timezone); ?>

                            </h4>

                        </div>

                        
                        <div class="div" style="margin: 10px">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="duration">Duration</label>
                                </div>

                                <select class="custom-select" id="duration" name="duration" disabled>
                                    <option value="0">Choose...</option>
                                    <option value="15">15 min</option>
                                    <option value="30">30 min</option>
                                    <option value="45">45 min</option>
                                    <option value="60">1 hour</option>
                                </select>

                            </div>
                        </div>

                        <div class="div" style="margin: 10px">

                            
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="time">Time slot</label>
                                </div>

                                <select class="custom-select" id="time" name="time" disabled>
                                    <option value="0">Select time</option>
                                </select>

                            </div>
                        </div>
                        <h3 id="msg" style="visibility: hidden;margin: 10px 10px 20px;"></h3>
                        <h3 id="msg2" style="margin: 10px 10px 20px;"></h3>

                        
                        <button value="<?php echo e($users[0]->id); ?>" name="btn" id="buton" type="submit" class=" btn btn-primary "
                                disabled>
                            Submit
                        </button>

                    </div>
                </div>
            </div>
        </form>
    </div>

    
    <script>

        let duration = document.getElementById("duration"),
            time = document.getElementById('time'),
            date = document.getElementById('date'),
            msg = document.getElementById('msg'),
            msg2 = document.getElementById('msg2'),
            buton = document.getElementById('buton');

        function check() {

            if (date.value != null && duration.value != "0" && time.value != "0") {
                buton.disabled = false;
                msg.innerHTML = "Your appointment will be on " + date.value + " from " + time.value;
                msg.style.visibility = "visible";
            } else {
                buton.disabled = true;
                msg.style.visibility = "hidden";
            }

        }

        duration.addEventListener('change', function () {
            time.value = "0";
            check();
            //getting time and convert to user time zone
                <?php
                $st = (new DateTime($users[0]->sTime, new DateTimeZone($users[0]->timezone)))
                    ->setTimezone(new DateTimeZone(auth()->user()->timezone));
                $et = (new DateTime($users[0]->eTime, new DateTimeZone($users[0]->timezone)))
                    ->setTimezone(new DateTimeZone(auth()->user()->timezone));
                ?>
                
            let indx = 0;
            time.innerHTML = "";
            time.options[indx++] = new Option("Select time", "0");


            if (duration.value === "0") {
                time.disabled = true;
                return;
            } else {
                time.disabled = false;
            }

            let dValue = parseInt(duration.value);
            let sdt = new Date(0, 0, 0, parseInt("<?php echo $st->format("H");?>"), parseInt("<?php echo $st->format("i"); ?>"));
            let edt = new Date(0, 0, 0, parseInt("<?php echo $et->format("H");?>"), parseInt("<?php echo $et->format("i"); ?>"));
            let ss = [], ee = [], dx = 0;

            <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $hi = (new DateTime($tt->sTime, new DateTimeZone($tt->timezone)))
                ->setTimezone(new DateTimeZone(auth()->user()->timezone));?>
                ss[dx] = new Date(0, 0, 0, parseInt("<?php echo $hi->format("H");?>"), parseInt("<?php echo $hi->format("i"); ?>"));
            <?php $hi = (new DateTime($tt->eTime, new DateTimeZone($tt->timezone)))
                ->setTimezone(new DateTimeZone(auth()->user()->timezone));?>
                ee[dx] = new Date(0, 0, 0, parseInt("<?php echo $hi->format("H");?>"), parseInt("<?php echo $hi->format("i"); ?>"));
            dx++;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      

            T:while (sdt.getHours() != edt.getHours()) {

                let x = (sdt.toLocaleString('en-US', {
                    minute: 'numeric',
                    hour: 'numeric',
                    hour12: true
                }));

                let sd2 = new Date(sdt);
                sdt.setMinutes(sdt.getMinutes() + dValue);
                let ed2 = new Date(sdt);

                for (let i = 0; i < ss.length; i++) {
                    if ((sd2 < ss[i] && ed2 > ss[i]) ||
                        (sd2 < ee[i] && ed2 > ee[i]) ||
                        (sd2 >= ss[i] && ed2 <= ee[i]) ||
                        (sd2 < ss[i] && ed2 > ee[i]))
                        continue T;
                }

                if (sdt.getHours() == edt.getHours() && sdt.getMinutes() > edt.getMinutes()) {
                    continue;
                }
                let s = x + "->"
                    + (sdt.toLocaleString('en-US', {
                        minute: 'numeric',
                        hour: 'numeric',
                        hour12: true
                    }));
                time.options[indx++] = new Option(s, s);
                sdt.setMinutes(sdt.getMinutes() - dValue + 15);
            }
        });

        date.addEventListener('change', function () {
            check();
            duration.disabled = date.value == null;
        });

        time.addEventListener('change', function () {
            check();
            // if (duration.value != "0" && time.value != "0") {
            //     msg.style.visibility = "visible";
            // } else {
            //     msg.style.visibility = "hidden";
            // }
        });

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalTry2\resources\views/appointments/create.blade.php ENDPATH**/ ?>