@extends('layouts.app')

@section('content')


    <div class="container">
        <form action="/profile" method="POST">
            {{csrf_field()}}
            <div class="row justify-content-center">
                <div class="col-md-6">

                    <div class="cards">

                        @foreach($users as $user)
                            <div class="card"
                                 style="text-align: center; margin: 10px;background-color: rgba(121,121,121,0.15) ">

                                {{--img--}}
                                <div class="card-img-top" style="margin: 10px">
                                    <img src="images/default.png" class="img card-img-top" alt="avatar"
                                         style="width: 150px; height: 150px; border-radius: 50%;">
                                </div>

                                <hr>
                                {{--Line--}}

                                {{--Name--}}
                                <h2>{{$user->fName}} {{$user->lName}}</h2>

                                {{--Job--}}
                                <h4>{{$user->major}}</h4>

                                <button name="btn" id="btn" class="btn btn-primary " value={{$user->id}}>More info
                                </button>

                            </div>
                        @endforeach


                    </div>

                </div>
            </div>
        </form>
    </div>

@endsection
