@extends('layouts.app')

@section('content')



    <div class="container">
        <form action="/store" method="POST">
            {{csrf_field()}}
            <div class="row justify-content-center">
                <div class="col-md-6">

                    <div class="card "
                         style="text-align: center;margin: 10px; background-color: rgba(121,121,121,0.15)">

                        <div class="card-header">Appointment</div>

                        {{--           date                 --}}
                        <div class="div" style="margin: 10px">
                            <label for="date" style="font-size: large; margin-right: 10px">Select date</label>
                            <input type="date" name="date" id="date">

                            {{--timezone--}}
                            <h4 style="margin: 10px">Time zone: {{auth()->user()->timezone}}
                            </h4>

                        </div>

                        {{--           duration             --}}
                        <div class="div" style="margin: 10px">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="duration">Duration</label>
                                </div>

                                <select class="custom-select" id="duration" name="duration">
                                    <option value="0">Choose...</option>
                                    <option value="15">15 min</option>
                                    <option value="30">30 min</option>
                                    <option value="45">45 min</option>
                                    <option value="60">1 hour</option>
                                </select>

                            </div>
                        </div>

                        <div class="div" style="margin: 10px">

                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="duration">Duration</label>
                                </div>


                                <select class="custom-select" id="time" name="time" disabled>

                                    {{--                                    <button id="start" value="{{ date("g A",strtotime($users[0]->sTime))}}"--}}
                                    {{--                                            hidden></button>--}}
                                    {{--                                    <button id="end" value="{{ date("g A",strtotime($users[0]->eTime))}}"--}}
                                    {{--                                            hidden></button>--}}

                                    <h5 hidden>
                                        {{$i=(int)(date("g",strtotime($users[0]->sTime)))}}
                                        {{$j=(int)(date("g",strtotime($users[0]->eTime)))}}
                                        {{$x=date("A",strtotime($users[0]->sTime))}}
                                        {{$y=date("A",strtotime($users[0]->eTime))}}
                                        {{$am='AM'}}
                                        {{$pm='PM'}}
                                    </h5>

                                    <option value={{$i.":00 ".$x}}>{{$i.":00 ".$x}}</option>
                                    @while($i!=$j || $x!=$y)

                                        {{--        <script>--}}
                                        {{--            document.getElementById("xx").textContent = document.getElementById("start").value;--}}
                                        {{--        </script>--}}

                                        <option value={{$i.":15 ".$x}}>{{$i.":15 ".$x}}</option>
                                        <option value={{$i.":30 ".$x}}>{{$i.":30 ".$x}}</option>
                                        <option value={{$i.":45 ".$x}}>{{$i.":45 ".$x}}</option>
                                        @if(($i+1)<12)
                                            <option value={{($i+1).":00 ".$x}}>{{($i+1).":00 ".$x}}</option>
                                        @else
                                            <h5 hidden>
                                                @if($x=$am)
                                                    {{$x=$pm}}
                                                @else
                                                    {{$x=$am}}
                                                @endif</h5>
                                            <option value={{(1).":00 ".$x}}>{{(1).":00 ".$x}}</option>
                                        @endif

                                        <h5 hidden>
                                            {{$i++}}
                                            @if($i>12)
                                                {{$i=1}}
                                                @if($x=$am)
                                                    {{$x=$pm}}
                                                @else
                                                    {{$x=$am}}
                                                @endif
                                            @endif
                                        </h5>

                                    @endwhile


                                </select>
                                {{--check if there is value or not--}}
                                <script>
                                    document.getElementById('duration').addEventListener('change', function () {
                                        document.getElementById('time').disabled = this.value == 0;
                                    });
                                </script>
                            </div>

                        </div>

                        {{--button                 --}}
                        <button type="submit" class=" btn btn-primary " >Submit</button>


                    </div>
                </div>
            </div>
        </form>
    </div>

@endsection
