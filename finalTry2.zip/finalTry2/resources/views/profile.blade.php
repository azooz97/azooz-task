@extends('layouts.app')

@section('content')

    <div class="container">
        <form action="/appointments/create" method="POST">
            {{csrf_field()}}
            <div class="row justify-content-center">
                <div class="col-md-6">

                    @foreach($users as $user)
                        <div class="card" style="margin: 10px;background-color: rgba(121,121,121,0.15) ">

                            {{--                                img--}}
                            <div class="card-img-top" style="text-align: center;margin: 10px">
                                <img src="images/default.png" class="img card-img-top" alt="avatar"
                                     style="width: 150px; height: 150px; border-radius: 50%;">
                            </div>

                            <hr>{{--Line--}}

                            {{--                                Name--}}
                            <h2 style="text-align: center">{{$user->fName}} {{$user->lName}}</h2>

                            {{--                                Job--}}
                            <h4 style="text-align: center">{{$user->major}}</h4>

                            <div class="card" style="margin: 20px; border-radius: 5%;
                             text-align: center; height: 80px;justify-content: center">

                                <h5>Country: {{$user->country}} </h5>
                                <h5>Working
                                    hours: {{ ((int)date('h',strtotime($user->sTime))).(date('A',strtotime($user->sTime)))}}
                                    -> {{ ((int)date('h',strtotime($user->eTime))).(date('A',strtotime($user->eTime)))}} </h5>

                            </div>


                            <button name="btn" id="btn" class="btn btn-primary "
                                    value={{$user->id}}>Book now
                            </button>


                        </div>
                    @endforeach


                </div>
            </div>
        </form>
    </div>




@endsection
