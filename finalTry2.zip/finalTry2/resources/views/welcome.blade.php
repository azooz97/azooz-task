@extends('layouts.app')

@section('content')



    <div class="card">

        <div class="collapse-content">

            <div class="collapse" id="collapseExample">

                <table class="table table-borderless table-sm mb-0">
                    <tbody>
                    <label>azooz</label>
                    </tbody>
                </table>

            </div>

            <hr class="">

            <a class="btn btn-flat red-text p-1 my-1 mr-0 mml-1 deep-purple-text collapsed" data-toggle="collapse"
               href="#collapseExample" aria-expanded="false" aria-controls="collapseExample"></a>

        </div>

    </div>



@endsection
