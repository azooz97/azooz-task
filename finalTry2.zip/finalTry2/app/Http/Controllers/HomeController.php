<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Appointment;


class HomeController extends Controller
{

    public function index()
    {
//        dd($users);
        $users = DB::select('select * from experts');
        return view('home')->with(['users' => $users]);

    }

    public function store(Request $request)
    {

    }
}
