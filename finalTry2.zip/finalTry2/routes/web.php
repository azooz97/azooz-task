<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;


Auth::routes();

Route::group(['middleware' => 'auth'], function () {

//    Route::get('/', function () {
//        return view('home');
//    });

    Route::get('/', 'HomeController@index');

//    Route::post('/', 'HomeController@store');
    Route::post('/store', 'ExpertController@store')->name('home');

    Route::get('/timezone', function () {
        return view('changetimezone');
    });



    Route::post('/','TimeZone@store');

    Route::post('/profile', 'ProfileController@store')->name('profile');

    Route::post('/appointments/create', 'AppointmentController@store')->name('appointments.create');


//    Route::get('/welcome', function () {
//        return view('welcome');
//    });


});


